# ./assembler input/simple.s out/test/simple.int out/test/simple.out 
./assembler input/combined.s out/test/combined.int out/test/combined.out 
# ./assembler input/comments.s out/test/comments.int out/test/comments.out 
# ./assembler input/imm.s out/test/imm.int out/test/imm.out 
# ./assembler input/labels.s out/test/labels.int out/test/labels.out 
# ./assembler input/pseudo.s out/test/pseudo.int out/test/pseudo.out 
# ./assembler input/rtypes.s out/test/rtypes.int out/test/rtypes.out 